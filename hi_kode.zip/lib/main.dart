//1)
// Diziyi tersine çeviren fonksiyon
List<int> tersCevir(List<int> dizi) {
  // Listin tersini alıp döndürüyoruz
  return dizi.reversed.toList();
}

void main() {
  // Örnek bir dizi oluşturuyoruz
  List<int> orijinalDizi = [1, 2, 3, 4, 5];

  // Diziyi ters çeviriyoruz
  List<int> tersDizi = tersCevir(orijinalDizi);

  // Orijinal diziyi ekrana basıyoruz
  print('Orijinal Dizi: $orijinalDizi');

  // Ters çevrilmiş diziyi ekrana basıyoruz
  print('Ters Dizi: $tersDizi');
}

/*2)

// Listenin elemanlarının toplamını bulan fonksiyon
int toplamBul(List<int> dizi) {
  int toplam = 0;
  for (int sayi in dizi) {
    toplam += sayi;
  }
  return toplam;
}

void main() {
  // Bir dizi oluşturuyoruz
  List<int> numbers = [5, 10, 15, 20, 25];
  
  // Dizinin toplamını buluyoruz
  int toplam = toplamBul(numbers);
  
  // Toplamı ekrana basıyoruz
  print('Dizinin Elemanlarının Toplamı: $toplam');
}

3)

void main() {
  int toplam = 0;
  int baslangic = 0;
  int bitis = 100;
  
  // 0'dan 100'e kadar olan sayıların toplamını buluyoruz
  for (int i = baslangic; i <= bitis; i++) {
    toplam += i;
  }
  
  // Ortalama = Toplam / Eleman Sayısı
  double ortalama = toplam / (bitis - baslangic + 1);
  
  // Ortalamayı ekrana bastırıyoruz
  print('0\'dan 100\'e kadar sayıların ortalaması: $ortalama');
}
*/
